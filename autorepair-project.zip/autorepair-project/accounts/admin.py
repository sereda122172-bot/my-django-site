from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User

from .models import Profile


class ProfileInline(admin.StackedInline):
    model = Profile
    can_delete = False


class UserAdmin(BaseUserAdmin):
    inlines = [ProfileInline]
    list_display = ('username', 'first_name', 'last_name', 'role', 'is_staff')

    @admin.display(description='Роль')
    def role(self, obj):
        return obj.profile.get_role_display() if hasattr(obj, 'profile') else '-'

    def get_inline_instances(self, request, obj=None):
        # при создании пользователя профиль создаётся сигналом
        if obj is None:
            return []
        return super().get_inline_instances(request, obj)


admin.site.unregister(User)
admin.site.register(User, UserAdmin)
