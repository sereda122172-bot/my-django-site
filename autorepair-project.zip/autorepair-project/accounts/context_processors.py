from .permissions import is_employee


def role(request):
    return {'user_is_employee': is_employee(request.user)}
