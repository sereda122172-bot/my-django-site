from django import forms
from django.conf import settings
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth.models import User

from config.bootstrap import BootstrapMixin

from .models import Profile


class LoginForm(BootstrapMixin, AuthenticationForm):
    pass


class RegisterForm(BootstrapMixin, UserCreationForm):
    first_name = forms.CharField(label='Имя', max_length=150)
    last_name = forms.CharField(label='Фамилия', max_length=150)
    phone = forms.CharField(label='Телефон', max_length=20, required=False)
    role = forms.ChoiceField(
        label='Регистрация как', choices=Profile.ROLE_CHOICES, initial=Profile.CLIENT,
    )
    employee_code = forms.CharField(
        label='Код сотрудника', required=False,
        help_text='Нужен только при регистрации сотрудника. Код выдаёт администратор.',
    )

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ('username', 'first_name', 'last_name')

    def clean(self):
        cleaned = super().clean()
        if cleaned.get('role') == Profile.EMPLOYEE:
            if cleaned.get('employee_code') != settings.EMPLOYEE_SIGNUP_CODE:
                self.add_error('employee_code', 'Неверный код сотрудника.')
        return cleaned

    def save(self, commit=True):
        user = super().save(commit=True)
        profile, _ = Profile.objects.get_or_create(user=user)
        profile.role = self.cleaned_data['role']
        profile.phone = self.cleaned_data['phone']
        profile.save()
        return user
