from django.conf import settings
from django.db import models


class Profile(models.Model):
    CLIENT = 'client'
    EMPLOYEE = 'employee'
    ROLE_CHOICES = [
        (CLIENT, 'Клиент'),
        (EMPLOYEE, 'Сотрудник'),
    ]

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name='profile', verbose_name='Пользователь',
    )
    role = models.CharField('Роль', max_length=20, choices=ROLE_CHOICES, default=CLIENT)
    phone = models.CharField('Телефон', max_length=20, blank=True)

    class Meta:
        verbose_name = 'Профиль'
        verbose_name_plural = 'Профили'

    def __str__(self):
        return f'{self.user} ({self.get_role_display()})'
