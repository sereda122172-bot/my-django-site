from functools import wraps

from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied

from .models import Profile


def is_employee(user):
    if not user.is_authenticated:
        return False
    if user.is_superuser:
        return True
    profile = getattr(user, 'profile', None)
    return bool(profile and profile.role == Profile.EMPLOYEE)


def employee_required(view):
    @login_required
    @wraps(view)
    def wrapper(request, *args, **kwargs):
        if not is_employee(request.user):
            raise PermissionDenied
        return view(request, *args, **kwargs)
    return wrapper


def client_required(view):
    @login_required
    @wraps(view)
    def wrapper(request, *args, **kwargs):
        if is_employee(request.user):
            raise PermissionDenied
        return view(request, *args, **kwargs)
    return wrapper
