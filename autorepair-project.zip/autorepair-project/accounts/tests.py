from django.contrib.auth.models import User
from django.test import TestCase, override_settings
from django.urls import reverse

from .models import Profile

PASSWORD = 'Str0ng-pass-2026'


def register_data(**extra):
    data = {
        'username': 'newuser', 'first_name': 'Иван', 'last_name': 'Иванов',
        'phone': '', 'role': 'client', 'employee_code': '',
        'password1': PASSWORD, 'password2': PASSWORD,
    }
    data.update(extra)
    return data


@override_settings(EMPLOYEE_SIGNUP_CODE='TEST-CODE')
class RegistrationTests(TestCase):
    def test_client_registration(self):
        response = self.client.post(reverse('accounts:register'), register_data())
        self.assertRedirects(response, reverse('orders:index'))
        user = User.objects.get(username='newuser')
        self.assertEqual(user.profile.role, Profile.CLIENT)

    def test_employee_needs_valid_code(self):
        response = self.client.post(
            reverse('accounts:register'),
            register_data(role='employee', employee_code='wrong'),
        )
        self.assertEqual(response.status_code, 200)
        self.assertFalse(User.objects.filter(username='newuser').exists())

    def test_employee_registration_with_code(self):
        self.client.post(
            reverse('accounts:register'),
            register_data(role='employee', employee_code='TEST-CODE'),
        )
        user = User.objects.get(username='newuser')
        self.assertEqual(user.profile.role, Profile.EMPLOYEE)

    def test_login_and_logout(self):
        User.objects.create_user('someone', password=PASSWORD)
        self.assertTrue(self.client.login(username='someone', password=PASSWORD))
        response = self.client.post(reverse('accounts:logout'))
        self.assertRedirects(response, reverse('accounts:login'))
