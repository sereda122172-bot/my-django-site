from django.db.models import Q

from accounts.permissions import is_employee

from .models import Car, Order


def orders_for(user):
    """Заказы, которые пользователю разрешено видеть."""
    qs = Order.objects.select_related('client', 'car', 'employee')
    if user.is_superuser:
        return qs
    if is_employee(user):
        return qs.filter(Q(employee=user) | Q(employee__isnull=True))
    return qs.filter(client=user)


def cars_for(user):
    """Автомобили, которые пользователю разрешено видеть."""
    qs = Car.objects.select_related('owner')
    if user.is_superuser:
        return qs
    if is_employee(user):
        return qs.filter(Q(orders__employee=user) | Q(added_by=user)).distinct()
    return qs.filter(owner=user)


def can_delete_order(user, order):
    if is_employee(user):
        return user.is_superuser or order.employee_id == user.pk
    return order.client_id == user.pk and order.status == Order.Status.NEW
