from django.contrib import admin

from .models import (
    Car, Material, Order, OrderPart, OrderService, OrderStraightening,
    Part, Service, StraighteningService,
)

admin.site.site_header = 'Автосервис: администрирование'
admin.site.site_title = 'Автосервис'


@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ['name', 'category', 'unit', 'price', 'is_active']
    list_filter = ['category', 'is_active']
    search_fields = ['name']
    list_editable = ['price', 'is_active']


@admin.register(StraighteningService)
class StraighteningServiceAdmin(admin.ModelAdmin):
    list_display = ['name', 'price', 'is_active']
    list_editable = ['price', 'is_active']
    search_fields = ['name']


@admin.register(Material)
class MaterialAdmin(admin.ModelAdmin):
    list_display = ['name', 'unit', 'consumption_per_sqm', 'price_per_unit', 'loss_factor']
    search_fields = ['name']


@admin.register(Part)
class PartAdmin(admin.ModelAdmin):
    list_display = ['name', 'default_area_sqm', 'fixed_material_price']
    search_fields = ['name']


@admin.register(Car)
class CarAdmin(admin.ModelAdmin):
    list_display = ['title', 'plate', 'owner', 'year']
    search_fields = ['title', 'plate', 'owner__username', 'owner__last_name']


class OrderServiceInline(admin.TabularInline):
    model = OrderService
    extra = 0


class OrderPartInline(admin.TabularInline):
    model = OrderPart
    extra = 0


class OrderStraighteningInline(admin.TabularInline):
    model = OrderStraightening
    extra = 0


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['id', 'client', 'car', 'employee', 'status', 'total_price', 'created_at']
    list_filter = ['status', 'created_at']
    search_fields = ['client__username', 'client__last_name', 'car__plate']
    readonly_fields = ['total_price']
    inlines = [OrderServiceInline, OrderPartInline, OrderStraighteningInline]
