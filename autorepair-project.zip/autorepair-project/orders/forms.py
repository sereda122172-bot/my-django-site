from django import forms
from django.contrib.auth.models import User
from django.db.models import Q
from django.forms import inlineformset_factory

from accounts.models import Profile
from config.bootstrap import BootstrapMixin

from .models import (
    Car, Order, OrderPart, OrderService, OrderStraightening,
    Service, StraighteningService,
)


def user_name(user):
    return user.get_full_name() or user.username


class CarForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = Car
        fields = ['title', 'plate', 'year']


class EmployeeCarForm(CarForm):
    class Meta(CarForm.Meta):
        fields = ['owner', 'title', 'plate', 'year']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        owner = self.fields['owner']
        owner.queryset = User.objects.filter(profile__role=Profile.CLIENT).order_by('last_name', 'username')
        owner.label_from_instance = user_name


class OrderRequestForm(BootstrapMixin, forms.ModelForm):
    """Заявка от клиента."""

    class Meta:
        model = Order
        fields = ['car', 'comment']
        widgets = {'comment': forms.Textarea(attrs={'rows': 4})}

    def __init__(self, *args, user, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['car'].queryset = Car.objects.filter(owner=user)
        self.fields['comment'].label = 'Что нужно сделать'


class OrderForm(BootstrapMixin, forms.ModelForm):
    """Заказ в работе у сотрудника."""

    class Meta:
        model = Order
        fields = ['car', 'status', 'comment', 'coefficient']
        widgets = {
            'comment': forms.Textarea(attrs={'rows': 3}),
            'coefficient': forms.NumberInput(attrs={'step': '0.01'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        car = self.fields['car']
        car.queryset = Car.objects.select_related('owner')
        car.label_from_instance = lambda c: f'{c.plate} — {c.title} ({user_name(c.owner)})'


class OrderServiceForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = OrderService
        fields = ['service', 'quantity', 'status']
        widgets = {'quantity': forms.NumberInput(attrs={'step': '0.01'})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        condition = Q(is_active=True)
        if self.instance.pk:
            condition |= Q(pk=self.instance.service_id)
        self.fields['service'].queryset = Service.objects.filter(condition)


class OrderPartForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = OrderPart
        fields = ['part', 'area_sqm']
        widgets = {'area_sqm': forms.NumberInput(attrs={'step': '0.01'})}


class OrderStraighteningForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = OrderStraightening
        fields = ['service', 'quantity', 'status']
        widgets = {'quantity': forms.NumberInput(attrs={'step': '0.01'})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        condition = Q(is_active=True)
        if self.instance.pk:
            condition |= Q(pk=self.instance.service_id)
        self.fields['service'].queryset = StraighteningService.objects.filter(condition)


ServiceFormSet = inlineformset_factory(
    Order, OrderService, form=OrderServiceForm, extra=3, can_delete=True,
)
PartFormSet = inlineformset_factory(
    Order, OrderPart, form=OrderPartForm, extra=2, can_delete=True,
)
StraighteningFormSet = inlineformset_factory(
    Order, OrderStraightening, form=OrderStraighteningForm, extra=1, can_delete=True,
)
