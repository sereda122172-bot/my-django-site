from decimal import Decimal

from django.contrib.auth.models import User
from django.core.management.base import BaseCommand

from accounts.models import Profile
from orders.models import (
    Car, Material, Order, OrderPart, OrderService, OrderStraightening,
    Part, Service, StraighteningService, WorkStatus,
)
from orders.services import recalculate

DEMO_PASSWORD = 'demo12345'
ADMIN_PASSWORD = 'admin12345'

SERVICES = [
    ('armature', 'Снять/установить дверь', 'шт.', '2500'),
    ('prep', 'Подготовка двери', 'шт.', '3500'),
    ('paint', 'Окраска двери', 'шт.', '6000'),
    ('repair', 'Ремонт вмятины двери', 'шт.', '4000'),
    ('extra', 'Полировка элемента', 'шт.', '1500'),
    ('paint', 'Окраска бампера', 'шт.', '7000'),
]
STRAIGHTENING = [
    ('Вытяжка геометрии кузова', '8000'),
    ('Контрольный замер геометрии', '1500'),
]
MATERIALS = [
    ('Грунт', 'л', '0.18', '1200'),
    ('Краска', 'л', '0.12', '2500'),
    ('Лак', 'л', '0.10', '2000'),
    ('Шпатлёвка', 'кг', '0.15', '500'),
]
PARTS = [
    ('Дверь', '1.80'),
    ('Крыло', '1.20'),
    ('Капот', '2.00'),
    ('Бампер', '1.50'),
]


class Command(BaseCommand):
    help = 'Заполняет базу демонстрационными данными (только если база пустая)'

    def add_arguments(self, parser):
        parser.add_argument('--force', action='store_true', help='Заполнить, даже если пользователи уже есть')

    def handle(self, *args, **options):
        if User.objects.exists() and not options['force']:
            self.stdout.write('В базе уже есть данные, демо-данные не добавлялись.')
            return

        self.create_reference_data()
        users = self.create_users()
        self.create_orders(users)

        self.stdout.write(self.style.SUCCESS('Демо-данные созданы.'))
        self.stdout.write(f'  Администратор: admin / {ADMIN_PASSWORD}')
        self.stdout.write(f'  Сотрудники:    master, master2 / {DEMO_PASSWORD}')
        self.stdout.write(f'  Клиенты:       client1, client2 / {DEMO_PASSWORD}')

    def create_reference_data(self):
        for category, name, unit, price in SERVICES:
            Service.objects.get_or_create(
                name=name, defaults={'category': category, 'unit': unit, 'price': Decimal(price)},
            )
        for name, price in STRAIGHTENING:
            StraighteningService.objects.get_or_create(name=name, defaults={'price': Decimal(price)})
        for name, unit, consumption, price in MATERIALS:
            Material.objects.get_or_create(
                name=name,
                defaults={
                    'unit': unit,
                    'consumption_per_sqm': Decimal(consumption),
                    'price_per_unit': Decimal(price),
                },
            )
        for name, area in PARTS:
            Part.objects.get_or_create(name=name, defaults={'default_area_sqm': Decimal(area)})

    def create_users(self):
        admin = User.objects.create_superuser(
            'admin', password=ADMIN_PASSWORD, first_name='Администратор', last_name='Системы',
        )
        people = {
            'master': ('Иван', 'Петров', Profile.EMPLOYEE, '+7 900 111-11-11'),
            'master2': ('Сергей', 'Орлов', Profile.EMPLOYEE, '+7 900 222-22-22'),
            'client1': ('Алексей', 'Смирнов', Profile.CLIENT, '+7 900 333-33-33'),
            'client2': ('Мария', 'Кузнецова', Profile.CLIENT, '+7 900 444-44-44'),
        }
        users = {'admin': admin}
        for username, (first, last, role, phone) in people.items():
            user = User.objects.create_user(
                username, password=DEMO_PASSWORD, first_name=first, last_name=last,
            )
            Profile.objects.filter(user=user).update(role=role, phone=phone)
            users[username] = user
        return users

    def create_orders(self, users):
        civic = Car.objects.create(owner=users['client1'], title='Honda Civic', plate='А123ВС77', year=2018)
        camry = Car.objects.create(owner=users['client1'], title='Toyota Camry', plate='К456ОР99', year=2020)
        rio = Car.objects.create(owner=users['client2'], title='Kia Rio', plate='М789ТХ50', year=2016)

        self.make_order(
            client=users['client1'], car=civic, employee=users['master'],
            status=Order.Status.IN_WORK, comment='Вмятина на передней двери после парковки.',
            services=[
                ('Снять/установить дверь', WorkStatus.DONE),
                ('Ремонт вмятины двери', WorkStatus.IN_PROGRESS),
                ('Подготовка двери', WorkStatus.PLANNED),
                ('Окраска двери', WorkStatus.PLANNED),
            ],
            parts=['Дверь'],
            straightening=[('Контрольный замер геометрии', WorkStatus.DONE)],
        )
        self.make_order(
            client=users['client1'], car=camry, employee=None,
            status=Order.Status.NEW, comment='Царапины на заднем бампере, нужна покраска.',
        )
        self.make_order(
            client=users['client2'], car=rio, employee=users['master2'],
            status=Order.Status.IN_WORK, comment='После ДТП: крыло и капот.',
            services=[
                ('Ремонт вмятины двери', WorkStatus.DONE),
                ('Окраска бампера', WorkStatus.IN_PROGRESS),
            ],
            parts=['Крыло', 'Капот'],
            straightening=[('Вытяжка геометрии кузова', WorkStatus.IN_PROGRESS)],
        )

    def make_order(self, client, car, employee, status, comment,
                   services=(), parts=(), straightening=()):
        order = Order.objects.create(
            client=client, car=car, employee=employee, status=status, comment=comment,
        )
        for name, line_status in services:
            OrderService.objects.create(
                order=order, service=Service.objects.get(name=name), status=line_status,
            )
        for name in parts:
            OrderPart.objects.create(order=order, part=Part.objects.get(name=name))
        for name, line_status in straightening:
            OrderStraightening.objects.create(
                order=order, service=StraighteningService.objects.get(name=name), status=line_status,
            )
        recalculate(order)
        return order
