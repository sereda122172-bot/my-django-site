from decimal import Decimal

from django.conf import settings
from django.core.validators import MinValueValidator
from django.db import models

User = settings.AUTH_USER_MODEL


class Service(models.Model):
    """Операция из фиксированного прайса."""

    CATEGORY_CHOICES = [
        ('armature', 'Арматурные'),
        ('prep', 'Подготовка'),
        ('paint', 'Окраска'),
        ('repair', 'Ремонт'),
        ('extra', 'Дополнительно'),
    ]

    category = models.CharField('Категория', max_length=20, choices=CATEGORY_CHOICES)
    name = models.CharField('Название', max_length=255)
    unit = models.CharField('Единица измерения', max_length=20)
    price = models.DecimalField('Цена', max_digits=10, decimal_places=2)
    is_active = models.BooleanField('Активна', default=True)

    class Meta:
        verbose_name = 'Операция'
        verbose_name_plural = 'Операции (прайс)'
        ordering = ['category', 'name']

    def __str__(self):
        return f'{self.name} — {self.price} ₽'


class StraighteningService(models.Model):
    """Стапельная работа."""

    name = models.CharField('Название', max_length=255)
    price = models.DecimalField('Цена', max_digits=10, decimal_places=2)
    is_active = models.BooleanField('Активна', default=True)

    class Meta:
        verbose_name = 'Стапельная работа'
        verbose_name_plural = 'Стапельные работы (прайс)'
        ordering = ['name']

    def __str__(self):
        return f'{self.name} — {self.price} ₽'


class Material(models.Model):
    """Материал с нормой расхода на 1 м²."""

    name = models.CharField('Название', max_length=255)
    unit = models.CharField('Единица измерения', max_length=20)
    consumption_per_sqm = models.DecimalField('Расход на 1 м²', max_digits=10, decimal_places=4)
    price_per_unit = models.DecimalField('Цена за единицу', max_digits=10, decimal_places=2)
    loss_factor = models.DecimalField(
        'Коэффициент потерь', max_digits=5, decimal_places=2, default=Decimal('1.15'),
    )

    class Meta:
        verbose_name = 'Материал'
        verbose_name_plural = 'Материалы'
        ordering = ['name']

    def __str__(self):
        return self.name


class Part(models.Model):
    """Кузовная деталь."""

    name = models.CharField('Название', max_length=100)
    default_area_sqm = models.DecimalField('Площадь по умолчанию, м²', max_digits=5, decimal_places=2)
    fixed_material_price = models.DecimalField(
        'Фиксированная стоимость материалов', max_digits=10, decimal_places=2,
        null=True, blank=True,
        help_text='Если заполнено, материалы по нормам не считаются.',
    )

    class Meta:
        verbose_name = 'Деталь'
        verbose_name_plural = 'Детали'
        ordering = ['name']

    def __str__(self):
        return self.name


class Car(models.Model):
    owner = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='cars', verbose_name='Владелец',
    )
    added_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='added_cars', verbose_name='Добавил',
    )
    title = models.CharField('Марка и модель', max_length=100)
    plate = models.CharField('Госномер', max_length=15)
    year = models.PositiveSmallIntegerField('Год выпуска', null=True, blank=True)

    class Meta:
        verbose_name = 'Автомобиль'
        verbose_name_plural = 'Автомобили'
        ordering = ['title']

    def __str__(self):
        return f'{self.title} ({self.plate})'


class WorkStatus(models.TextChoices):
    PLANNED = 'planned', 'Запланировано'
    IN_PROGRESS = 'in_progress', 'В работе'
    DONE = 'done', 'Выполнено'


class Order(models.Model):
    class Status(models.TextChoices):
        NEW = 'new', 'Новая заявка'
        IN_WORK = 'in_work', 'В работе'
        READY = 'ready', 'Готов к выдаче'
        DONE = 'done', 'Выдан'

    client = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='orders', verbose_name='Клиент',
    )
    car = models.ForeignKey(
        Car, on_delete=models.RESTRICT, related_name='orders', verbose_name='Автомобиль',
    )
    employee = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='assigned_orders', verbose_name='Сотрудник',
    )
    status = models.CharField('Статус', max_length=20, choices=Status.choices, default=Status.NEW)
    comment = models.TextField('Комментарий', blank=True)
    coefficient = models.DecimalField(
        'Коэффициент наценки', max_digits=5, decimal_places=2,
        default=Decimal('1.40'), validators=[MinValueValidator(Decimal('1.00'))],
    )
    total_price = models.DecimalField('Итоговая сумма', max_digits=12, decimal_places=2, default=0)
    created_at = models.DateTimeField('Дата создания', auto_now_add=True)

    class Meta:
        verbose_name = 'Заказ'
        verbose_name_plural = 'Заказы'
        ordering = ['-created_at']

    def __str__(self):
        return f'Заказ №{self.pk}'

    def progress(self):
        """Процент выполненных работ в заказе."""
        lines = list(self.services.all()) + list(self.straightening.all())
        if not lines:
            return 0
        done = sum(1 for line in lines if line.status == WorkStatus.DONE)
        return round(done * 100 / len(lines))


class OrderService(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='services')
    service = models.ForeignKey(Service, on_delete=models.PROTECT, verbose_name='Операция')
    quantity = models.DecimalField(
        'Количество', max_digits=6, decimal_places=2,
        default=Decimal('1.00'), validators=[MinValueValidator(Decimal('0.01'))],
    )
    status = models.CharField(
        'Статус', max_length=20, choices=WorkStatus.choices, default=WorkStatus.PLANNED,
    )

    class Meta:
        verbose_name = 'Операция в заказе'
        verbose_name_plural = 'Операции в заказе'

    @property
    def total(self):
        return self.service.price * self.quantity


class OrderPart(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='parts')
    part = models.ForeignKey(Part, on_delete=models.PROTECT, verbose_name='Деталь')
    area_sqm = models.DecimalField(
        'Площадь, м²', max_digits=5, decimal_places=2, null=True, blank=True,
        validators=[MinValueValidator(Decimal('0.01'))],
        help_text='Если пусто, берётся площадь детали по умолчанию.',
    )

    class Meta:
        verbose_name = 'Деталь в заказе'
        verbose_name_plural = 'Детали в заказе'

    @property
    def area(self):
        return self.area_sqm if self.area_sqm is not None else self.part.default_area_sqm


class OrderStraightening(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='straightening')
    service = models.ForeignKey(
        StraighteningService, on_delete=models.PROTECT, verbose_name='Стапельная работа',
    )
    quantity = models.DecimalField(
        'Количество', max_digits=6, decimal_places=2,
        default=Decimal('1.00'), validators=[MinValueValidator(Decimal('0.01'))],
    )
    status = models.CharField(
        'Статус', max_length=20, choices=WorkStatus.choices, default=WorkStatus.PLANNED,
    )

    class Meta:
        verbose_name = 'Стапельная работа в заказе'
        verbose_name_plural = 'Стапельные работы в заказе'

    @property
    def total(self):
        return self.service.price * self.quantity
