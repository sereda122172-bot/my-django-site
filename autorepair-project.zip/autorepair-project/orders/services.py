"""Расчёт стоимости ремонта.

работы = операции + стапельные работы
себестоимость = работы + 30% от работ + материалы
итог = себестоимость * коэффициент наценки
"""
from decimal import ROUND_HALF_UP, Decimal

from .models import Material

REPAIR_PERCENT = Decimal('0.30')


def money(value):
    return Decimal(value).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)


def calculate_materials(parts, materials):
    """Стоимость материалов по деталям заказа."""
    total = Decimal('0')
    for order_part in parts:
        part = order_part.part
        if part.fixed_material_price is not None:
            total += part.fixed_material_price
            continue
        for material in materials:
            total += (
                order_part.area
                * material.consumption_per_sqm
                * material.loss_factor
                * material.price_per_unit
            )
    return money(total)


def calculate_total(services, parts, straightening, materials, coefficient):
    services_total = sum((item.total for item in services), Decimal('0'))
    straightening_total = sum((item.total for item in straightening), Decimal('0'))
    materials_total = calculate_materials(parts, materials)

    work_total = services_total + straightening_total
    repair = money(work_total * REPAIR_PERCENT)
    cost_price = money(work_total + repair + materials_total)
    markup = money(cost_price * (coefficient - Decimal('1')))
    total = money(cost_price + markup)

    return {
        'services': money(services_total),
        'straightening': money(straightening_total),
        'materials': materials_total,
        'repair': repair,
        'cost_price': cost_price,
        'markup': markup,
        'markup_percent': money((coefficient - Decimal('1')) * Decimal('100')),
        'total': total,
    }


def order_result(order):
    return calculate_total(
        order.services.select_related('service'),
        order.parts.select_related('part'),
        order.straightening.select_related('service'),
        Material.objects.all(),
        order.coefficient,
    )


def recalculate(order):
    """Пересчитывает и сохраняет итоговую сумму заказа."""
    result = order_result(order)
    order.total_price = result['total']
    order.save(update_fields=['total_price'])
    return result
