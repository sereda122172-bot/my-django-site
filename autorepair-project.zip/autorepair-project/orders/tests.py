from decimal import Decimal

from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse

from accounts.models import Profile

from .models import (
    Car, Material, Order, OrderPart, OrderService, OrderStraightening,
    Part, Service, StraighteningService, WorkStatus,
)
from .services import recalculate


def make_user(username, role=Profile.CLIENT):
    user = User.objects.create_user(username, password='test-pass-123')
    Profile.objects.filter(user=user).update(role=role)
    return user


class CalculationTests(TestCase):
    def test_total_without_materials(self):
        client_user = make_user('c1')
        car = Car.objects.create(owner=client_user, title='Test', plate='A1')
        order = Order.objects.create(client=client_user, car=car, coefficient=Decimal('1.40'))
        service = Service.objects.create(category='paint', name='Окраска', unit='шт.', price=Decimal('1000'))
        stapel = StraighteningService.objects.create(name='Стапель', price=Decimal('500'))
        OrderService.objects.create(order=order, service=service, quantity=Decimal('2'))
        OrderStraightening.objects.create(order=order, service=stapel)

        result = recalculate(order)

        # работы 2500, ремонт 30% = 750, себестоимость 3250, наценка 40% = 1300
        self.assertEqual(result['repair'], Decimal('750.00'))
        self.assertEqual(result['cost_price'], Decimal('3250.00'))
        self.assertEqual(result['total'], Decimal('4550.00'))
        order.refresh_from_db()
        self.assertEqual(order.total_price, Decimal('4550.00'))

    def test_materials_by_area(self):
        client_user = make_user('c1')
        car = Car.objects.create(owner=client_user, title='Test', plate='A1')
        order = Order.objects.create(client=client_user, car=car)
        part = Part.objects.create(name='Дверь', default_area_sqm=Decimal('2.00'))
        Material.objects.create(
            name='Краска', unit='л', consumption_per_sqm=Decimal('0.1'),
            price_per_unit=Decimal('1000'), loss_factor=Decimal('1.00'),
        )
        OrderPart.objects.create(order=order, part=part)

        result = recalculate(order)

        # 2.0 м2 * 0.1 л/м2 * 1.00 * 1000 = 200
        self.assertEqual(result['materials'], Decimal('200.00'))

    def test_progress(self):
        client_user = make_user('c1')
        car = Car.objects.create(owner=client_user, title='Test', plate='A1')
        order = Order.objects.create(client=client_user, car=car)
        service = Service.objects.create(category='paint', name='Окраска', unit='шт.', price=Decimal('1000'))
        OrderService.objects.create(order=order, service=service, status=WorkStatus.DONE)
        OrderService.objects.create(order=order, service=service, status=WorkStatus.PLANNED)
        self.assertEqual(order.progress(), 50)


class AccessTests(TestCase):
    def setUp(self):
        self.client1 = make_user('client1')
        self.client2 = make_user('client2')
        self.master = make_user('master', Profile.EMPLOYEE)
        self.car1 = Car.objects.create(owner=self.client1, title='Honda', plate='AAA111')
        self.car2 = Car.objects.create(owner=self.client2, title='Kia', plate='BBB222')
        self.order1 = Order.objects.create(client=self.client1, car=self.car1)
        self.order2 = Order.objects.create(client=self.client2, car=self.car2)

    def test_anonymous_redirected_to_login(self):
        response = self.client.get(reverse('orders:index'))
        self.assertRedirects(response, f"{reverse('accounts:login')}?next={reverse('orders:index')}")

    def test_client_sees_only_own_orders(self):
        self.client.login(username='client1', password='test-pass-123')
        response = self.client.get(reverse('orders:index'))
        self.assertContains(response, 'AAA111')
        self.assertNotContains(response, 'BBB222')

    def test_client_cannot_open_foreign_order(self):
        self.client.login(username='client1', password='test-pass-123')
        response = self.client.get(reverse('orders:order_detail', args=[self.order2.pk]))
        self.assertEqual(response.status_code, 404)

    def test_client_sees_only_own_cars(self):
        self.client.login(username='client1', password='test-pass-123')
        response = self.client.get(reverse('orders:car_list'))
        self.assertContains(response, 'AAA111')
        self.assertNotContains(response, 'BBB222')

    def test_client_cannot_edit_orders(self):
        self.client.login(username='client1', password='test-pass-123')
        response = self.client.get(reverse('orders:order_edit', args=[self.order1.pk]))
        self.assertEqual(response.status_code, 403)

    def test_employee_does_not_see_orders_of_other_employee(self):
        other = make_user('master2', Profile.EMPLOYEE)
        self.order1.employee = other
        self.order1.save()
        self.client.login(username='master', password='test-pass-123')
        response = self.client.get(reverse('orders:order_detail', args=[self.order1.pk]))
        self.assertEqual(response.status_code, 404)

    def test_employee_takes_free_order(self):
        self.client.login(username='master', password='test-pass-123')
        response = self.client.post(reverse('orders:order_take', args=[self.order1.pk]))
        self.assertEqual(response.status_code, 302)
        self.order1.refresh_from_db()
        self.assertEqual(self.order1.employee, self.master)
        self.assertEqual(self.order1.status, Order.Status.IN_WORK)

    def test_client_creates_request_for_own_car(self):
        self.client.login(username='client1', password='test-pass-123')
        response = self.client.post(reverse('orders:order_request'), {
            'car': self.car1.pk, 'comment': 'Нужна покраска',
        })
        self.assertEqual(response.status_code, 302)
        self.assertTrue(Order.objects.filter(client=self.client1, comment='Нужна покраска').exists())

    def test_client_cannot_request_for_foreign_car(self):
        self.client.login(username='client1', password='test-pass-123')
        response = self.client.post(reverse('orders:order_request'), {
            'car': self.car2.pk, 'comment': 'Чужая машина',
        })
        self.assertEqual(response.status_code, 200)
        self.assertFalse(Order.objects.filter(comment='Чужая машина').exists())


class EmployeeWorkflowTests(TestCase):
    def setUp(self):
        self.master = make_user('master', Profile.EMPLOYEE)
        self.client_user = make_user('client1')
        self.car = Car.objects.create(owner=self.client_user, title='Honda', plate='AAA111')
        self.service = Service.objects.create(
            category='paint', name='Окраска', unit='шт.', price=Decimal('1000'),
        )

    def test_employee_creates_order_with_lines(self):
        self.client.login(username='master', password='test-pass-123')
        data = {
            'car': self.car.pk, 'status': 'in_work', 'comment': '', 'coefficient': '1.40',
            'services-TOTAL_FORMS': '1', 'services-INITIAL_FORMS': '0',
            'services-MIN_NUM_FORMS': '0', 'services-MAX_NUM_FORMS': '1000',
            'services-0-service': self.service.pk, 'services-0-quantity': '2',
            'services-0-status': 'planned',
            'parts-TOTAL_FORMS': '0', 'parts-INITIAL_FORMS': '0',
            'parts-MIN_NUM_FORMS': '0', 'parts-MAX_NUM_FORMS': '1000',
            'straightening-TOTAL_FORMS': '0', 'straightening-INITIAL_FORMS': '0',
            'straightening-MIN_NUM_FORMS': '0', 'straightening-MAX_NUM_FORMS': '1000',
        }
        response = self.client.post(reverse('orders:order_create'), data)
        self.assertEqual(response.status_code, 302)
        order = Order.objects.get()
        self.assertEqual(order.client, self.client_user)
        self.assertEqual(order.employee, self.master)
        self.assertEqual(order.services.count(), 1)
        # работы 2000, ремонт 600, себестоимость 2600, итог 3640
        self.assertEqual(order.total_price, Decimal('3640.00'))

    def test_employee_adds_line_to_existing_order(self):
        order = Order.objects.create(client=self.client_user, car=self.car, employee=self.master)
        line = OrderService.objects.create(order=order, service=self.service)
        self.client.login(username='master', password='test-pass-123')
        data = {
            'car': self.car.pk, 'status': 'in_work', 'comment': '', 'coefficient': '1.40',
            'services-TOTAL_FORMS': '2', 'services-INITIAL_FORMS': '1',
            'services-MIN_NUM_FORMS': '0', 'services-MAX_NUM_FORMS': '1000',
            'services-0-id': line.pk, 'services-0-order': order.pk,
            'services-0-service': self.service.pk, 'services-0-quantity': '1',
            'services-0-status': 'planned',
            'services-1-service': self.service.pk, 'services-1-quantity': '1',
            'services-1-status': 'planned',
            'parts-TOTAL_FORMS': '0', 'parts-INITIAL_FORMS': '0',
            'parts-MIN_NUM_FORMS': '0', 'parts-MAX_NUM_FORMS': '1000',
            'straightening-TOTAL_FORMS': '0', 'straightening-INITIAL_FORMS': '0',
            'straightening-MIN_NUM_FORMS': '0', 'straightening-MAX_NUM_FORMS': '1000',
        }
        response = self.client.post(reverse('orders:order_edit', args=[order.pk]), data)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(order.services.count(), 2)

    def test_line_advance_changes_status_and_order(self):
        order = Order.objects.create(
            client=self.client_user, car=self.car, employee=self.master, status=Order.Status.IN_WORK,
        )
        line = OrderService.objects.create(order=order, service=self.service)
        self.client.login(username='master', password='test-pass-123')
        url = reverse('orders:line_advance', args=['service', line.pk])
        self.client.post(url)
        line.refresh_from_db()
        self.assertEqual(line.status, WorkStatus.IN_PROGRESS)
        self.client.post(url)
        line.refresh_from_db()
        order.refresh_from_db()
        self.assertEqual(line.status, WorkStatus.DONE)
        self.assertEqual(order.status, Order.Status.READY)
