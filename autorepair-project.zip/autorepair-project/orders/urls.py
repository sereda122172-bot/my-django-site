from django.urls import path

from . import views

app_name = 'orders'

urlpatterns = [
    path('', views.index, name='index'),
    path('about/', views.about, name='about'),

    path('orders/request/', views.order_request, name='order_request'),
    path('orders/new/', views.order_create, name='order_create'),
    path('orders/<int:pk>/', views.order_detail, name='order_detail'),
    path('orders/<int:pk>/edit/', views.order_edit, name='order_edit'),
    path('orders/<int:pk>/take/', views.order_take, name='order_take'),
    path('orders/<int:pk>/delete/', views.order_delete, name='order_delete'),

    path('cars/', views.car_list, name='car_list'),
    path('cars/new/', views.car_create, name='car_create'),
    path('cars/<int:pk>/edit/', views.car_edit, name='car_edit'),
    path('cars/<int:pk>/delete/', views.car_delete, name='car_delete'),

    path('processes/', views.processes, name='processes'),
    path('processes/<str:kind>/<int:pk>/advance/', views.line_advance, name='line_advance'),
]
