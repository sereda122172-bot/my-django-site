from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from accounts.permissions import client_required, employee_required, is_employee

from .access import can_delete_order, cars_for, orders_for
from .forms import (
    CarForm, EmployeeCarForm, OrderForm, OrderRequestForm,
    PartFormSet, ServiceFormSet, StraighteningFormSet,
)
from .models import Order, OrderService, OrderStraightening, WorkStatus
from .services import order_result, recalculate


def about(request):
    return render(request, 'orders/about.html')


@login_required
def index(request):
    user = request.user
    if not is_employee(user):
        return render(request, 'orders/index.html', {'orders': orders_for(user)})

    base = Order.objects.select_related('client', 'car', 'employee')
    context = {
        'my_orders': base.filter(employee=user),
        'free_orders': base.filter(employee__isnull=True),
    }
    if user.is_superuser:
        context['other_orders'] = base.exclude(employee=user).exclude(employee__isnull=True)
    return render(request, 'orders/index.html', context)


@login_required
def order_detail(request, pk):
    order = get_object_or_404(orders_for(request.user), pk=pk)
    return render(request, 'orders/order_detail.html', {
        'order': order,
        'result': order_result(order),
        'can_delete': can_delete_order(request.user, order),
    })


@client_required
def order_request(request):
    """Клиент создаёт заявку на ремонт."""
    if not request.user.cars.exists():
        messages.info(request, 'Сначала добавьте автомобиль.')
        return redirect('orders:car_create')

    if request.method == 'POST':
        form = OrderRequestForm(request.POST, user=request.user)
        if form.is_valid():
            order = form.save(commit=False)
            order.client = request.user
            order.save()
            messages.success(request, 'Заявка отправлена. Сотрудник возьмёт её в работу.')
            return redirect('orders:order_detail', pk=order.pk)
    else:
        form = OrderRequestForm(user=request.user)

    return render(request, 'orders/order_request_form.html', {'form': form})


def _save_order(request, form, formsets):
    order = form.save(commit=False)
    order.client = order.car.owner
    if order.employee is None:
        order.employee = request.user
    order.save()
    for formset in formsets:
        formset.instance = order
        formset.save()
    recalculate(order)
    return order


@employee_required
def order_create(request):
    if request.method == 'POST':
        form = OrderForm(request.POST)
        formsets = [
            ServiceFormSet(request.POST, instance=form.instance, prefix='services'),
            PartFormSet(request.POST, instance=form.instance, prefix='parts'),
            StraighteningFormSet(request.POST, instance=form.instance, prefix='straightening'),
        ]
        if form.is_valid() and all(fs.is_valid() for fs in formsets):
            order = _save_order(request, form, formsets)
            messages.success(request, 'Заказ создан.')
            return redirect('orders:order_detail', pk=order.pk)
    else:
        form = OrderForm()
        formsets = [
            ServiceFormSet(prefix='services'),
            PartFormSet(prefix='parts'),
            StraighteningFormSet(prefix='straightening'),
        ]
    return _render_order_form(request, form, formsets, 'Новый заказ')


@employee_required
def order_edit(request, pk):
    order = get_object_or_404(orders_for(request.user), pk=pk)

    if request.method == 'POST':
        form = OrderForm(request.POST, instance=order)
        formsets = [
            ServiceFormSet(request.POST, instance=order, prefix='services'),
            PartFormSet(request.POST, instance=order, prefix='parts'),
            StraighteningFormSet(request.POST, instance=order, prefix='straightening'),
        ]
        if form.is_valid() and all(fs.is_valid() for fs in formsets):
            order = _save_order(request, form, formsets)
            messages.success(request, 'Изменения сохранены.')
            return redirect('orders:order_detail', pk=order.pk)
    else:
        form = OrderForm(instance=order)
        formsets = [
            ServiceFormSet(instance=order, prefix='services'),
            PartFormSet(instance=order, prefix='parts'),
            StraighteningFormSet(instance=order, prefix='straightening'),
        ]
    return _render_order_form(request, form, formsets, f'Заказ №{order.pk}: редактирование')


def _render_order_form(request, form, formsets, title):
    service_fs, part_fs, straightening_fs = formsets
    return render(request, 'orders/order_form.html', {
        'form': form,
        'service_formset': service_fs,
        'part_formset': part_fs,
        'straightening_formset': straightening_fs,
        'title': title,
    })


@employee_required
@require_POST
def order_take(request, pk):
    order = get_object_or_404(Order, pk=pk, employee__isnull=True)
    order.employee = request.user
    if order.status == Order.Status.NEW:
        order.status = Order.Status.IN_WORK
    order.save(update_fields=['employee', 'status'])
    messages.success(request, f'Заказ №{order.pk} взят в работу.')
    return redirect('orders:order_detail', pk=order.pk)


@login_required
def order_delete(request, pk):
    order = get_object_or_404(orders_for(request.user), pk=pk)
    if not can_delete_order(request.user, order):
        raise PermissionDenied
    if request.method == 'POST':
        order.delete()
        messages.success(request, 'Заказ удалён.')
        return redirect('orders:index')
    return render(request, 'orders/order_confirm_delete.html', {'order': order})


@login_required
def car_list(request):
    return render(request, 'orders/car_list.html', {'cars': cars_for(request.user)})


def _car_form_class(user):
    return EmployeeCarForm if is_employee(user) else CarForm


@login_required
def car_create(request):
    form_class = _car_form_class(request.user)
    if request.method == 'POST':
        form = form_class(request.POST)
        if form.is_valid():
            car = form.save(commit=False)
            if is_employee(request.user):
                car.added_by = request.user
            else:
                car.owner = request.user
            car.save()
            messages.success(request, 'Автомобиль добавлен.')
            return redirect('orders:car_list')
    else:
        form = form_class()
    return render(request, 'orders/car_form.html', {'form': form, 'title': 'Новый автомобиль'})


@login_required
def car_edit(request, pk):
    car = get_object_or_404(cars_for(request.user), pk=pk)
    form_class = _car_form_class(request.user)
    if request.method == 'POST':
        form = form_class(request.POST, instance=car)
        if form.is_valid():
            form.save()
            messages.success(request, 'Данные автомобиля сохранены.')
            return redirect('orders:car_list')
    else:
        form = form_class(instance=car)
    return render(request, 'orders/car_form.html', {'form': form, 'title': 'Редактирование автомобиля'})


@login_required
def car_delete(request, pk):
    car = get_object_or_404(cars_for(request.user), pk=pk)
    if request.method == 'POST':
        if car.orders.exists():
            messages.error(request, 'Нельзя удалить автомобиль, по которому есть заказы.')
        else:
            car.delete()
            messages.success(request, 'Автомобиль удалён.')
        return redirect('orders:car_list')
    return render(request, 'orders/car_confirm_delete.html', {'car': car})


@login_required
def processes(request):
    """Ход работ: клиент видит свои заказы, сотрудник - свои в работе."""
    user = request.user
    orders = orders_for(user)
    if is_employee(user) and not user.is_superuser:
        orders = orders.filter(employee=user)
    orders = orders.exclude(status=Order.Status.DONE).prefetch_related(
        'services__service', 'straightening__service',
    )
    return render(request, 'orders/processes.html', {'orders': orders})


@employee_required
@require_POST
def line_advance(request, kind, pk):
    model = {'service': OrderService, 'straightening': OrderStraightening}.get(kind)
    if model is None:
        raise Http404
    line = get_object_or_404(model.objects.select_related('order'), pk=pk)
    order = line.order
    if not (request.user.is_superuser or order.employee_id == request.user.pk):
        raise PermissionDenied

    next_status = {
        WorkStatus.PLANNED: WorkStatus.IN_PROGRESS,
        WorkStatus.IN_PROGRESS: WorkStatus.DONE,
    }.get(line.status)
    if next_status:
        line.status = next_status
        line.save(update_fields=['status'])
        if order.status == Order.Status.IN_WORK and order.progress() == 100:
            order.status = Order.Status.READY
            order.save(update_fields=['status'])
    return redirect('orders:processes')
