@echo off
chcp 65001 >nul
cd /d "%~dp0"

set PY=
where py >nul 2>nul && set PY=py -3
if not defined PY where python >nul 2>nul && set PY=python
if not defined PY goto no_python

%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)"
if errorlevel 1 goto old_python

if not exist ".venv\Scripts\python.exe" (
    echo Создаю виртуальное окружение...
    %PY% -m venv .venv
    if errorlevel 1 goto fail
)

set VPY=.venv\Scripts\python.exe

echo Устанавливаю зависимости...
"%VPY%" -m pip install -q -r requirements.txt
if errorlevel 1 goto fail

"%VPY%" manage.py migrate
if errorlevel 1 goto fail

"%VPY%" manage.py seed_demo

echo.
echo Сайт откроется на http://127.0.0.1:8000/  Остановить сервер: Ctrl+C
start "" cmd /c "timeout /t 3 >nul & start http://127.0.0.1:8000/"
"%VPY%" manage.py runserver
goto end

:no_python
echo Python не найден. Установите Python 3.10 или новее с python.org
echo и отметьте галочку "Add python.exe to PATH".
goto fail

:old_python
echo Нужен Python 3.10 или новее.
goto fail

:fail
echo.
echo Запуск не удался.
pause
exit /b 1

:end
