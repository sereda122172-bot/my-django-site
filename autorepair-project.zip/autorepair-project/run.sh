#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

PY=python3
command -v "$PY" >/dev/null 2>&1 || PY=python

if [ ! -x .venv/bin/python ]; then
    echo "Создаю виртуальное окружение..."
    "$PY" -m venv .venv
fi

.venv/bin/python -m pip install -q -r requirements.txt
.venv/bin/python manage.py migrate
.venv/bin/python manage.py seed_demo

echo
echo "Сайт: http://127.0.0.1:8000/  (остановить: Ctrl+C)"
.venv/bin/python manage.py runserver
